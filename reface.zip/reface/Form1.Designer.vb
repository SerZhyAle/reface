﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class F
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(F))
        TabsBlock = New TabControl()
        PageTask = New TabPage()
        PictureBoxFace = New PictureBox()
        ReFace = New Button()
        CaptionName = New Label()
        TextBoxName = New TextBox()
        CheckBoxFaceHidden = New CheckBox()
        LabelPrefix = New Label()
        PictureBoxFaceLabel = New Label()
        ButFaceFolder = New Button()
        CheckBoxFacesFromFolder = New CheckBox()
        ButtonFaceFile = New Button()
        LabelFace = New Label()
        TextFace = New TextBox()
        TabControlSource = New TabControl()
        TabPageSourceImage = New TabPage()
        ButtonDeleteSourceImage = New Button()
        ButtonRotate = New Button()
        ButtonLoadPrev = New Button()
        ButtonLoadNext = New Button()
        ButtonNext = New Button()
        ReSource = New Button()
        TextBoxSourceName = New TextBox()
        LabelNameSource = New Label()
        CheckBoxSourceHidden = New CheckBox()
        LabelSourceName = New Label()
        PictureBoxSourceLabel = New Label()
        ButtonImageAddTask = New Button()
        ButtonImageStart = New Button()
        ButtonSourceImageFolder = New Button()
        CheckBoxSourceImagesFromFolder = New CheckBox()
        ButtonSourceImageFile = New Button()
        LabelSource = New Label()
        TextBoxSourceImage = New TextBox()
        PictureBoxSourceImage = New PictureBox()
        TabPageSourceVideo = New TabPage()
        TextBoxNameSourceVideo = New TextBox()
        Label1 = New Label()
        PictureBoxVideo = New PictureBox()
        PictureBoxSourceVideoLabel = New Label()
        LabelSourceVideoName = New Label()
        ButtonSourceVideoPlay = New Button()
        ButtonSourceVideoFolder = New Button()
        CheckBoxSourceVideoFromFolder = New CheckBox()
        ButtonSourceVideoFile = New Button()
        ButtonVideoAddTask = New Button()
        ButtonVideoStart = New Button()
        LabelSourceVideo = New Label()
        TextBoxSourceVideo = New TextBox()
        PageTasks = New TabPage()
        ButtonTasksOneBatch = New Button()
        ButtonTasksOneByOne = New Button()
        ButtonTasksRun = New Button()
        ButtonTasksClear = New Button()
        ButtonTasksRemove = New Button()
        ListBox1 = New ListBox()
        PageSettings = New TabPage()
        ButtonRunThisCommand = New Button()
        TextBoxLastCommandLine = New TextBox()
        CheckBoxNoWindow = New CheckBox()
        CheckBox512 = New CheckBox()
        CheckBoxRunMinimized = New CheckBox()
        ButtonOutputOpen = New Button()
        ButtonOutputFolder = New Button()
        LabelOutputFolder = New Label()
        TextBoxOutputFolder = New TextBox()
        ButtonSimSwapFolder = New Button()
        LabelSimSwap = New Label()
        TextSimSwapFolder = New TextBox()
        ButtonAnaconda = New Button()
        LabelAnaconda = New Label()
        TextAnaconda = New TextBox()
        TabResult = New TabPage()
        Button2 = New Button()
        ButtonDelResult = New Button()
        ButtonResult = New Button()
        PictureBoxResult = New PictureBox()
        TextBoxResult = New TextBox()
        OpenFileDialog1 = New OpenFileDialog()
        FolderBrowserDialog1 = New FolderBrowserDialog()
        ButtonTempFolder = New Button()
        ButtonOpenOutputFolder = New Button()
        LabelLast = New Label()
        LabelLastFileName = New Label()
        ButtonOpenLastFile = New Button()
        Button1 = New Button()
        TabsBlock.SuspendLayout()
        PageTask.SuspendLayout()
        CType(PictureBoxFace, ComponentModel.ISupportInitialize).BeginInit()
        TabControlSource.SuspendLayout()
        TabPageSourceImage.SuspendLayout()
        CType(PictureBoxSourceImage, ComponentModel.ISupportInitialize).BeginInit()
        TabPageSourceVideo.SuspendLayout()
        CType(PictureBoxVideo, ComponentModel.ISupportInitialize).BeginInit()
        PageTasks.SuspendLayout()
        PageSettings.SuspendLayout()
        TabResult.SuspendLayout()
        CType(PictureBoxResult, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' TabsBlock
        ' 
        TabsBlock.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        TabsBlock.Controls.Add(PageTask)
        TabsBlock.Controls.Add(PageTasks)
        TabsBlock.Controls.Add(PageSettings)
        TabsBlock.Controls.Add(TabResult)
        TabsBlock.Font = New Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point)
        TabsBlock.Location = New Point(2, 8)
        TabsBlock.Margin = New Padding(4, 5, 4, 5)
        TabsBlock.Name = "TabsBlock"
        TabsBlock.SelectedIndex = 0
        TabsBlock.Size = New Size(1404, 1226)
        TabsBlock.TabIndex = 0
        ' 
        ' PageTask
        ' 
        PageTask.Controls.Add(PictureBoxFace)
        PageTask.Controls.Add(ReFace)
        PageTask.Controls.Add(CaptionName)
        PageTask.Controls.Add(TextBoxName)
        PageTask.Controls.Add(CheckBoxFaceHidden)
        PageTask.Controls.Add(LabelPrefix)
        PageTask.Controls.Add(PictureBoxFaceLabel)
        PageTask.Controls.Add(ButFaceFolder)
        PageTask.Controls.Add(CheckBoxFacesFromFolder)
        PageTask.Controls.Add(ButtonFaceFile)
        PageTask.Controls.Add(LabelFace)
        PageTask.Controls.Add(TextFace)
        PageTask.Controls.Add(TabControlSource)
        PageTask.Location = New Point(8, 65)
        PageTask.Margin = New Padding(4, 5, 4, 5)
        PageTask.Name = "PageTask"
        PageTask.Padding = New Padding(4, 5, 4, 5)
        PageTask.Size = New Size(1388, 1153)
        PageTask.TabIndex = 0
        PageTask.Text = "Task"
        PageTask.UseVisualStyleBackColor = True
        ' 
        ' PictureBoxFace
        ' 
        PictureBoxFace.BackColor = Color.WhiteSmoke
        PictureBoxFace.Location = New Point(1123, 20)
        PictureBoxFace.Margin = New Padding(4, 5, 4, 5)
        PictureBoxFace.Name = "PictureBoxFace"
        PictureBoxFace.Size = New Size(224, 224)
        PictureBoxFace.SizeMode = PictureBoxSizeMode.Zoom
        PictureBoxFace.TabIndex = 0
        PictureBoxFace.TabStop = False
        ' 
        ' ReFace
        ' 
        ReFace.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ReFace.Location = New Point(1058, 20)
        ReFace.Name = "ReFace"
        ReFace.Size = New Size(56, 51)
        ReFace.TabIndex = 17
        ReFace.Text = "re"
        ReFace.UseVisualStyleBackColor = True
        ' 
        ' CaptionName
        ' 
        CaptionName.AutoSize = True
        CaptionName.Location = New Point(3, 76)
        CaptionName.Name = "CaptionName"
        CaptionName.Size = New Size(122, 51)
        CaptionName.TabIndex = 16
        CaptionName.Text = "Name"
        ' 
        ' TextBoxName
        ' 
        TextBoxName.Font = New Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxName.Location = New Point(131, 76)
        TextBoxName.Name = "TextBoxName"
        TextBoxName.Size = New Size(433, 38)
        TextBoxName.TabIndex = 15
        ' 
        ' CheckBoxFaceHidden
        ' 
        CheckBoxFaceHidden.AutoSize = True
        CheckBoxFaceHidden.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        CheckBoxFaceHidden.Location = New Point(1029, 189)
        CheckBoxFaceHidden.Margin = New Padding(2)
        CheckBoxFaceHidden.Name = "CheckBoxFaceHidden"
        CheckBoxFaceHidden.Size = New Size(85, 29)
        CheckBoxFaceHidden.TabIndex = 14
        CheckBoxFaceHidden.Text = "hide"
        CheckBoxFaceHidden.UseVisualStyleBackColor = True
        ' 
        ' LabelPrefix
        ' 
        LabelPrefix.AutoSize = True
        LabelPrefix.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        LabelPrefix.ForeColor = Color.Maroon
        LabelPrefix.Location = New Point(3, 124)
        LabelPrefix.Margin = New Padding(4, 0, 4, 0)
        LabelPrefix.Name = "LabelPrefix"
        LabelPrefix.Size = New Size(92, 36)
        LabelPrefix.TabIndex = 13
        LabelPrefix.Text = "no file"
        ' 
        ' PictureBoxFaceLabel
        ' 
        PictureBoxFaceLabel.AutoSize = True
        PictureBoxFaceLabel.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point)
        PictureBoxFaceLabel.ForeColor = SystemColors.HotTrack
        PictureBoxFaceLabel.Location = New Point(3, 152)
        PictureBoxFaceLabel.Margin = New Padding(4, 0, 4, 0)
        PictureBoxFaceLabel.Name = "PictureBoxFaceLabel"
        PictureBoxFaceLabel.Size = New Size(86, 36)
        PictureBoxFaceLabel.TabIndex = 12
        PictureBoxFaceLabel.Text = "no file"
        ' 
        ' ButFaceFolder
        ' 
        ButFaceFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButFaceFolder.Location = New Point(1010, 75)
        ButFaceFolder.Margin = New Padding(4, 5, 4, 5)
        ButFaceFolder.Name = "ButFaceFolder"
        ButFaceFolder.Size = New Size(108, 55)
        ButFaceFolder.TabIndex = 5
        ButFaceFolder.Text = "Folder.."
        ButFaceFolder.UseVisualStyleBackColor = True
        ' 
        ' CheckBoxFacesFromFolder
        ' 
        CheckBoxFacesFromFolder.AutoSize = True
        CheckBoxFacesFromFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        CheckBoxFacesFromFolder.Location = New Point(662, 89)
        CheckBoxFacesFromFolder.Margin = New Padding(4, 5, 4, 5)
        CheckBoxFacesFromFolder.Name = "CheckBoxFacesFromFolder"
        CheckBoxFacesFromFolder.Size = New Size(320, 29)
        CheckBoxFacesFromFolder.TabIndex = 4
        CheckBoxFacesFromFolder.Text = "For all the Faces from Folder"
        CheckBoxFacesFromFolder.UseVisualStyleBackColor = True
        ' 
        ' ButtonFaceFile
        ' 
        ButtonFaceFile.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonFaceFile.Location = New Point(954, 20)
        ButtonFaceFile.Margin = New Padding(4, 5, 4, 5)
        ButtonFaceFile.Name = "ButtonFaceFile"
        ButtonFaceFile.Size = New Size(90, 62)
        ButtonFaceFile.TabIndex = 3
        ButtonFaceFile.Text = "File.."
        ButtonFaceFile.UseVisualStyleBackColor = True
        ' 
        ' LabelFace
        ' 
        LabelFace.AutoSize = True
        LabelFace.Location = New Point(3, 18)
        LabelFace.Margin = New Padding(4, 0, 4, 0)
        LabelFace.Name = "LabelFace"
        LabelFace.Size = New Size(97, 51)
        LabelFace.TabIndex = 2
        LabelFace.Text = "Face"
        ' 
        ' TextFace
        ' 
        TextFace.BackColor = SystemColors.Info
        TextFace.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        TextFace.Location = New Point(131, 20)
        TextFace.Margin = New Padding(4, 5, 4, 5)
        TextFace.Name = "TextFace"
        TextFace.Size = New Size(807, 31)
        TextFace.TabIndex = 1
        ' 
        ' TabControlSource
        ' 
        TabControlSource.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        TabControlSource.Controls.Add(TabPageSourceImage)
        TabControlSource.Controls.Add(TabPageSourceVideo)
        TabControlSource.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        TabControlSource.Location = New Point(4, 237)
        TabControlSource.Margin = New Padding(4, 5, 4, 5)
        TabControlSource.Name = "TabControlSource"
        TabControlSource.SelectedIndex = 0
        TabControlSource.Size = New Size(1380, 911)
        TabControlSource.TabIndex = 11
        ' 
        ' TabPageSourceImage
        ' 
        TabPageSourceImage.BackColor = Color.Linen
        TabPageSourceImage.Controls.Add(ButtonDeleteSourceImage)
        TabPageSourceImage.Controls.Add(ButtonRotate)
        TabPageSourceImage.Controls.Add(ButtonLoadPrev)
        TabPageSourceImage.Controls.Add(ButtonLoadNext)
        TabPageSourceImage.Controls.Add(ButtonNext)
        TabPageSourceImage.Controls.Add(ReSource)
        TabPageSourceImage.Controls.Add(TextBoxSourceName)
        TabPageSourceImage.Controls.Add(LabelNameSource)
        TabPageSourceImage.Controls.Add(CheckBoxSourceHidden)
        TabPageSourceImage.Controls.Add(LabelSourceName)
        TabPageSourceImage.Controls.Add(PictureBoxSourceLabel)
        TabPageSourceImage.Controls.Add(ButtonImageAddTask)
        TabPageSourceImage.Controls.Add(ButtonImageStart)
        TabPageSourceImage.Controls.Add(ButtonSourceImageFolder)
        TabPageSourceImage.Controls.Add(CheckBoxSourceImagesFromFolder)
        TabPageSourceImage.Controls.Add(ButtonSourceImageFile)
        TabPageSourceImage.Controls.Add(LabelSource)
        TabPageSourceImage.Controls.Add(TextBoxSourceImage)
        TabPageSourceImage.Controls.Add(PictureBoxSourceImage)
        TabPageSourceImage.Location = New Point(8, 51)
        TabPageSourceImage.Margin = New Padding(4, 5, 4, 5)
        TabPageSourceImage.Name = "TabPageSourceImage"
        TabPageSourceImage.Padding = New Padding(4, 5, 4, 5)
        TabPageSourceImage.Size = New Size(1364, 852)
        TabPageSourceImage.TabIndex = 0
        TabPageSourceImage.Text = "Source Image"
        ' 
        ' ButtonDeleteSourceImage
        ' 
        ButtonDeleteSourceImage.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonDeleteSourceImage.Location = New Point(1051, 185)
        ButtonDeleteSourceImage.Name = "ButtonDeleteSourceImage"
        ButtonDeleteSourceImage.Size = New Size(55, 30)
        ButtonDeleteSourceImage.TabIndex = 25
        ButtonDeleteSourceImage.Text = "del"
        ButtonDeleteSourceImage.UseVisualStyleBackColor = True
        ' 
        ' ButtonRotate
        ' 
        ButtonRotate.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonRotate.Location = New Point(1293, 172)
        ButtonRotate.Name = "ButtonRotate"
        ButtonRotate.Size = New Size(60, 43)
        ButtonRotate.TabIndex = 24
        ButtonRotate.Text = "R"
        ButtonRotate.UseVisualStyleBackColor = True
        ' 
        ' ButtonLoadPrev
        ' 
        ButtonLoadPrev.Location = New Point(1111, 153)
        ButtonLoadPrev.Name = "ButtonLoadPrev"
        ButtonLoadPrev.Size = New Size(54, 62)
        ButtonLoadPrev.TabIndex = 23
        ButtonLoadPrev.Text = "<"
        ButtonLoadPrev.UseVisualStyleBackColor = True
        ' 
        ' ButtonLoadNext
        ' 
        ButtonLoadNext.Location = New Point(1178, 153)
        ButtonLoadNext.Name = "ButtonLoadNext"
        ButtonLoadNext.Size = New Size(95, 64)
        ButtonLoadNext.TabIndex = 22
        ButtonLoadNext.Text = ">"
        ButtonLoadNext.UseVisualStyleBackColor = True
        ' 
        ' ButtonNext
        ' 
        ButtonNext.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonNext.Location = New Point(541, 153)
        ButtonNext.Name = "ButtonNext"
        ButtonNext.Size = New Size(94, 64)
        ButtonNext.TabIndex = 21
        ButtonNext.Text = "Next"
        ButtonNext.UseVisualStyleBackColor = True
        ' 
        ' ReSource
        ' 
        ReSource.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ReSource.Location = New Point(1046, 22)
        ReSource.Name = "ReSource"
        ReSource.Size = New Size(56, 60)
        ReSource.TabIndex = 20
        ReSource.Text = "re"
        ReSource.UseVisualStyleBackColor = True
        ' 
        ' TextBoxSourceName
        ' 
        TextBoxSourceName.Font = New Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxSourceName.Location = New Point(115, 76)
        TextBoxSourceName.Name = "TextBoxSourceName"
        TextBoxSourceName.Size = New Size(433, 38)
        TextBoxSourceName.TabIndex = 19
        ' 
        ' LabelNameSource
        ' 
        LabelNameSource.AutoSize = True
        LabelNameSource.Location = New Point(7, 78)
        LabelNameSource.Name = "LabelNameSource"
        LabelNameSource.Size = New Size(103, 37)
        LabelNameSource.TabIndex = 18
        LabelNameSource.Text = "Name"
        ' 
        ' CheckBoxSourceHidden
        ' 
        CheckBoxSourceHidden.AutoSize = True
        CheckBoxSourceHidden.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        CheckBoxSourceHidden.Location = New Point(451, 193)
        CheckBoxSourceHidden.Margin = New Padding(2)
        CheckBoxSourceHidden.Name = "CheckBoxSourceHidden"
        CheckBoxSourceHidden.Size = New Size(85, 29)
        CheckBoxSourceHidden.TabIndex = 17
        CheckBoxSourceHidden.Text = "hide"
        CheckBoxSourceHidden.UseVisualStyleBackColor = True
        ' 
        ' LabelSourceName
        ' 
        LabelSourceName.AutoSize = True
        LabelSourceName.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        LabelSourceName.ForeColor = Color.Maroon
        LabelSourceName.Location = New Point(7, 153)
        LabelSourceName.Margin = New Padding(4, 0, 4, 0)
        LabelSourceName.Name = "LabelSourceName"
        LabelSourceName.Size = New Size(92, 36)
        LabelSourceName.TabIndex = 16
        LabelSourceName.Text = "no file"
        ' 
        ' PictureBoxSourceLabel
        ' 
        PictureBoxSourceLabel.AutoSize = True
        PictureBoxSourceLabel.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point)
        PictureBoxSourceLabel.ForeColor = SystemColors.Highlight
        PictureBoxSourceLabel.Location = New Point(7, 185)
        PictureBoxSourceLabel.Margin = New Padding(4, 0, 4, 0)
        PictureBoxSourceLabel.Name = "PictureBoxSourceLabel"
        PictureBoxSourceLabel.Size = New Size(86, 36)
        PictureBoxSourceLabel.TabIndex = 15
        PictureBoxSourceLabel.Text = "no file"
        ' 
        ' ButtonImageAddTask
        ' 
        ButtonImageAddTask.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonImageAddTask.Location = New Point(845, 153)
        ButtonImageAddTask.Margin = New Padding(4, 5, 4, 5)
        ButtonImageAddTask.Name = "ButtonImageAddTask"
        ButtonImageAddTask.Size = New Size(195, 68)
        ButtonImageAddTask.TabIndex = 14
        ButtonImageAddTask.Text = "Add task"
        ButtonImageAddTask.UseVisualStyleBackColor = True
        ' 
        ' ButtonImageStart
        ' 
        ButtonImageStart.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonImageStart.Location = New Point(642, 153)
        ButtonImageStart.Margin = New Padding(4, 5, 4, 5)
        ButtonImageStart.Name = "ButtonImageStart"
        ButtonImageStart.Size = New Size(195, 68)
        ButtonImageStart.TabIndex = 13
        ButtonImageStart.Text = "START"
        ButtonImageStart.UseVisualStyleBackColor = True
        ' 
        ' ButtonSourceImageFolder
        ' 
        ButtonSourceImageFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonSourceImageFolder.Location = New Point(994, 81)
        ButtonSourceImageFolder.Margin = New Padding(4, 5, 4, 5)
        ButtonSourceImageFolder.Name = "ButtonSourceImageFolder"
        ButtonSourceImageFolder.Size = New Size(108, 62)
        ButtonSourceImageFolder.TabIndex = 12
        ButtonSourceImageFolder.Text = "Folder.."
        ButtonSourceImageFolder.UseVisualStyleBackColor = True
        ' 
        ' CheckBoxSourceImagesFromFolder
        ' 
        CheckBoxSourceImagesFromFolder.AutoSize = True
        CheckBoxSourceImagesFromFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        CheckBoxSourceImagesFromFolder.Location = New Point(650, 99)
        CheckBoxSourceImagesFromFolder.Margin = New Padding(4, 5, 4, 5)
        CheckBoxSourceImagesFromFolder.Name = "CheckBoxSourceImagesFromFolder"
        CheckBoxSourceImagesFromFolder.Size = New Size(330, 29)
        CheckBoxSourceImagesFromFolder.TabIndex = 11
        CheckBoxSourceImagesFromFolder.Text = "For all the Images from Folder"
        CheckBoxSourceImagesFromFolder.UseVisualStyleBackColor = True
        ' 
        ' ButtonSourceImageFile
        ' 
        ButtonSourceImageFile.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonSourceImageFile.Location = New Point(942, 24)
        ButtonSourceImageFile.Margin = New Padding(4, 5, 4, 5)
        ButtonSourceImageFile.Name = "ButtonSourceImageFile"
        ButtonSourceImageFile.Size = New Size(90, 60)
        ButtonSourceImageFile.TabIndex = 10
        ButtonSourceImageFile.Text = "File.."
        ButtonSourceImageFile.UseVisualStyleBackColor = True
        ' 
        ' LabelSource
        ' 
        LabelSource.AutoSize = True
        LabelSource.Location = New Point(7, 22)
        LabelSource.Margin = New Padding(4, 0, 4, 0)
        LabelSource.Name = "LabelSource"
        LabelSource.Size = New Size(105, 37)
        LabelSource.TabIndex = 6
        LabelSource.Text = "Image"
        ' 
        ' TextBoxSourceImage
        ' 
        TextBoxSourceImage.BackColor = SystemColors.GradientInactiveCaption
        TextBoxSourceImage.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxSourceImage.Location = New Point(115, 24)
        TextBoxSourceImage.Margin = New Padding(4, 5, 4, 5)
        TextBoxSourceImage.Name = "TextBoxSourceImage"
        TextBoxSourceImage.Size = New Size(811, 31)
        TextBoxSourceImage.TabIndex = 7
        ' 
        ' PictureBoxSourceImage
        ' 
        PictureBoxSourceImage.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        PictureBoxSourceImage.BackColor = Color.Linen
        PictureBoxSourceImage.Location = New Point(0, 231)
        PictureBoxSourceImage.Margin = New Padding(4, 5, 4, 5)
        PictureBoxSourceImage.Name = "PictureBoxSourceImage"
        PictureBoxSourceImage.Size = New Size(1356, 616)
        PictureBoxSourceImage.SizeMode = PictureBoxSizeMode.Zoom
        PictureBoxSourceImage.TabIndex = 9
        PictureBoxSourceImage.TabStop = False
        ' 
        ' TabPageSourceVideo
        ' 
        TabPageSourceVideo.BackColor = Color.Moccasin
        TabPageSourceVideo.Controls.Add(TextBoxNameSourceVideo)
        TabPageSourceVideo.Controls.Add(Label1)
        TabPageSourceVideo.Controls.Add(PictureBoxVideo)
        TabPageSourceVideo.Controls.Add(PictureBoxSourceVideoLabel)
        TabPageSourceVideo.Controls.Add(LabelSourceVideoName)
        TabPageSourceVideo.Controls.Add(ButtonSourceVideoPlay)
        TabPageSourceVideo.Controls.Add(ButtonSourceVideoFolder)
        TabPageSourceVideo.Controls.Add(CheckBoxSourceVideoFromFolder)
        TabPageSourceVideo.Controls.Add(ButtonSourceVideoFile)
        TabPageSourceVideo.Controls.Add(ButtonVideoAddTask)
        TabPageSourceVideo.Controls.Add(ButtonVideoStart)
        TabPageSourceVideo.Controls.Add(LabelSourceVideo)
        TabPageSourceVideo.Controls.Add(TextBoxSourceVideo)
        TabPageSourceVideo.Location = New Point(8, 51)
        TabPageSourceVideo.Margin = New Padding(4, 5, 4, 5)
        TabPageSourceVideo.Name = "TabPageSourceVideo"
        TabPageSourceVideo.Padding = New Padding(4, 5, 4, 5)
        TabPageSourceVideo.Size = New Size(1364, 852)
        TabPageSourceVideo.TabIndex = 1
        TabPageSourceVideo.Text = "Source Video"
        ' 
        ' TextBoxNameSourceVideo
        ' 
        TextBoxNameSourceVideo.Font = New Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxNameSourceVideo.Location = New Point(109, 68)
        TextBoxNameSourceVideo.Name = "TextBoxNameSourceVideo"
        TextBoxNameSourceVideo.Size = New Size(433, 38)
        TextBoxNameSourceVideo.TabIndex = 25
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(0, 69)
        Label1.Name = "Label1"
        Label1.Size = New Size(103, 37)
        Label1.TabIndex = 24
        Label1.Text = "Name"
        ' 
        ' PictureBoxVideo
        ' 
        PictureBoxVideo.Location = New Point(0, 198)
        PictureBoxVideo.Name = "PictureBoxVideo"
        PictureBoxVideo.Size = New Size(1357, 654)
        PictureBoxVideo.TabIndex = 23
        PictureBoxVideo.TabStop = False
        ' 
        ' PictureBoxSourceVideoLabel
        ' 
        PictureBoxSourceVideoLabel.AutoSize = True
        PictureBoxSourceVideoLabel.Font = New Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point)
        PictureBoxSourceVideoLabel.ForeColor = SystemColors.HotTrack
        PictureBoxSourceVideoLabel.Location = New Point(4, 139)
        PictureBoxSourceVideoLabel.Margin = New Padding(4, 0, 4, 0)
        PictureBoxSourceVideoLabel.Name = "PictureBoxSourceVideoLabel"
        PictureBoxSourceVideoLabel.Size = New Size(86, 36)
        PictureBoxSourceVideoLabel.TabIndex = 22
        PictureBoxSourceVideoLabel.Text = "no file"
        ' 
        ' LabelSourceVideoName
        ' 
        LabelSourceVideoName.AutoSize = True
        LabelSourceVideoName.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        LabelSourceVideoName.ForeColor = Color.Maroon
        LabelSourceVideoName.Location = New Point(4, 101)
        LabelSourceVideoName.Margin = New Padding(4, 0, 4, 0)
        LabelSourceVideoName.Name = "LabelSourceVideoName"
        LabelSourceVideoName.Size = New Size(92, 36)
        LabelSourceVideoName.TabIndex = 21
        LabelSourceVideoName.Text = "no file"
        ' 
        ' ButtonSourceVideoPlay
        ' 
        ButtonSourceVideoPlay.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonSourceVideoPlay.Location = New Point(1217, 7)
        ButtonSourceVideoPlay.Margin = New Padding(4, 5, 4, 5)
        ButtonSourceVideoPlay.Name = "ButtonSourceVideoPlay"
        ButtonSourceVideoPlay.Size = New Size(108, 60)
        ButtonSourceVideoPlay.TabIndex = 20
        ButtonSourceVideoPlay.Text = "Play.."
        ButtonSourceVideoPlay.UseVisualStyleBackColor = True
        ' 
        ' ButtonSourceVideoFolder
        ' 
        ButtonSourceVideoFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonSourceVideoFolder.Location = New Point(1106, 77)
        ButtonSourceVideoFolder.Margin = New Padding(4, 5, 4, 5)
        ButtonSourceVideoFolder.Name = "ButtonSourceVideoFolder"
        ButtonSourceVideoFolder.Size = New Size(108, 55)
        ButtonSourceVideoFolder.TabIndex = 19
        ButtonSourceVideoFolder.Text = "Folder.."
        ButtonSourceVideoFolder.UseVisualStyleBackColor = True
        ' 
        ' CheckBoxSourceVideoFromFolder
        ' 
        CheckBoxSourceVideoFromFolder.AutoSize = True
        CheckBoxSourceVideoFromFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        CheckBoxSourceVideoFromFolder.Location = New Point(658, 77)
        CheckBoxSourceVideoFromFolder.Margin = New Padding(4, 5, 4, 5)
        CheckBoxSourceVideoFromFolder.Name = "CheckBoxSourceVideoFromFolder"
        CheckBoxSourceVideoFromFolder.Size = New Size(225, 29)
        CheckBoxSourceVideoFromFolder.TabIndex = 18
        CheckBoxSourceVideoFromFolder.Text = "Videos from Folder"
        CheckBoxSourceVideoFromFolder.UseVisualStyleBackColor = True
        ' 
        ' ButtonSourceVideoFile
        ' 
        ButtonSourceVideoFile.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonSourceVideoFile.Location = New Point(1108, 7)
        ButtonSourceVideoFile.Margin = New Padding(4, 5, 4, 5)
        ButtonSourceVideoFile.Name = "ButtonSourceVideoFile"
        ButtonSourceVideoFile.Size = New Size(90, 60)
        ButtonSourceVideoFile.TabIndex = 17
        ButtonSourceVideoFile.Text = "File.."
        ButtonSourceVideoFile.UseVisualStyleBackColor = True
        ' 
        ' ButtonVideoAddTask
        ' 
        ButtonVideoAddTask.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonVideoAddTask.Location = New Point(891, 116)
        ButtonVideoAddTask.Margin = New Padding(4, 5, 4, 5)
        ButtonVideoAddTask.Name = "ButtonVideoAddTask"
        ButtonVideoAddTask.Size = New Size(207, 68)
        ButtonVideoAddTask.TabIndex = 16
        ButtonVideoAddTask.Text = "Add task"
        ButtonVideoAddTask.UseVisualStyleBackColor = True
        ' 
        ' ButtonVideoStart
        ' 
        ButtonVideoStart.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonVideoStart.Location = New Point(650, 116)
        ButtonVideoStart.Margin = New Padding(4, 5, 4, 5)
        ButtonVideoStart.Name = "ButtonVideoStart"
        ButtonVideoStart.Size = New Size(233, 68)
        ButtonVideoStart.TabIndex = 15
        ButtonVideoStart.Text = "START"
        ButtonVideoStart.UseVisualStyleBackColor = True
        ' 
        ' LabelSourceVideo
        ' 
        LabelSourceVideo.AutoSize = True
        LabelSourceVideo.Location = New Point(-4, 2)
        LabelSourceVideo.Margin = New Padding(4, 0, 4, 0)
        LabelSourceVideo.Name = "LabelSourceVideo"
        LabelSourceVideo.Size = New Size(99, 37)
        LabelSourceVideo.TabIndex = 10
        LabelSourceVideo.Text = "Video"
        ' 
        ' TextBoxSourceVideo
        ' 
        TextBoxSourceVideo.BackColor = SystemColors.ControlLight
        TextBoxSourceVideo.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxSourceVideo.Location = New Point(115, 7)
        TextBoxSourceVideo.Margin = New Padding(4, 5, 4, 5)
        TextBoxSourceVideo.Name = "TextBoxSourceVideo"
        TextBoxSourceVideo.Size = New Size(983, 47)
        TextBoxSourceVideo.TabIndex = 9
        ' 
        ' PageTasks
        ' 
        PageTasks.Controls.Add(ButtonTasksOneBatch)
        PageTasks.Controls.Add(ButtonTasksOneByOne)
        PageTasks.Controls.Add(ButtonTasksRun)
        PageTasks.Controls.Add(ButtonTasksClear)
        PageTasks.Controls.Add(ButtonTasksRemove)
        PageTasks.Controls.Add(ListBox1)
        PageTasks.Location = New Point(8, 65)
        PageTasks.Margin = New Padding(4, 5, 4, 5)
        PageTasks.Name = "PageTasks"
        PageTasks.Padding = New Padding(4, 5, 4, 5)
        PageTasks.Size = New Size(1388, 1153)
        PageTasks.TabIndex = 1
        PageTasks.Text = "Tasks.."
        PageTasks.UseVisualStyleBackColor = True
        ' 
        ' ButtonTasksOneBatch
        ' 
        ButtonTasksOneBatch.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonTasksOneBatch.Location = New Point(459, 3)
        ButtonTasksOneBatch.Name = "ButtonTasksOneBatch"
        ButtonTasksOneBatch.Size = New Size(220, 51)
        ButtonTasksOneBatch.TabIndex = 5
        ButtonTasksOneBatch.Text = "RUN Tasks as Batch"
        ButtonTasksOneBatch.UseVisualStyleBackColor = True
        ' 
        ' ButtonTasksOneByOne
        ' 
        ButtonTasksOneByOne.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonTasksOneByOne.Location = New Point(685, 3)
        ButtonTasksOneByOne.Name = "ButtonTasksOneByOne"
        ButtonTasksOneByOne.Size = New Size(220, 51)
        ButtonTasksOneByOne.TabIndex = 4
        ButtonTasksOneByOne.Text = "RUN one-by-one Tasks"
        ButtonTasksOneByOne.UseVisualStyleBackColor = True
        ' 
        ' ButtonTasksRun
        ' 
        ButtonTasksRun.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonTasksRun.Location = New Point(911, 3)
        ButtonTasksRun.Name = "ButtonTasksRun"
        ButtonTasksRun.Size = New Size(220, 51)
        ButtonTasksRun.TabIndex = 3
        ButtonTasksRun.Text = "RUN all Tasks"
        ButtonTasksRun.UseVisualStyleBackColor = True
        ' 
        ' ButtonTasksClear
        ' 
        ButtonTasksClear.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonTasksClear.Location = New Point(233, 3)
        ButtonTasksClear.Name = "ButtonTasksClear"
        ButtonTasksClear.Size = New Size(220, 51)
        ButtonTasksClear.TabIndex = 2
        ButtonTasksClear.Text = "Clear list"
        ButtonTasksClear.UseVisualStyleBackColor = True
        ' 
        ' ButtonTasksRemove
        ' 
        ButtonTasksRemove.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonTasksRemove.Location = New Point(7, 3)
        ButtonTasksRemove.Name = "ButtonTasksRemove"
        ButtonTasksRemove.Size = New Size(220, 51)
        ButtonTasksRemove.TabIndex = 1
        ButtonTasksRemove.Text = "Remove Selected"
        ButtonTasksRemove.UseVisualStyleBackColor = True
        ' 
        ' ListBox1
        ' 
        ListBox1.Dock = DockStyle.Bottom
        ListBox1.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        ListBox1.FormattingEnabled = True
        ListBox1.HorizontalScrollbar = True
        ListBox1.ItemHeight = 37
        ListBox1.Location = New Point(4, 71)
        ListBox1.Name = "ListBox1"
        ListBox1.ScrollAlwaysVisible = True
        ListBox1.SelectionMode = SelectionMode.MultiSimple
        ListBox1.Size = New Size(1380, 1077)
        ListBox1.TabIndex = 0
        ' 
        ' PageSettings
        ' 
        PageSettings.Controls.Add(ButtonRunThisCommand)
        PageSettings.Controls.Add(TextBoxLastCommandLine)
        PageSettings.Controls.Add(CheckBoxNoWindow)
        PageSettings.Controls.Add(CheckBox512)
        PageSettings.Controls.Add(CheckBoxRunMinimized)
        PageSettings.Controls.Add(ButtonOutputOpen)
        PageSettings.Controls.Add(ButtonOutputFolder)
        PageSettings.Controls.Add(LabelOutputFolder)
        PageSettings.Controls.Add(TextBoxOutputFolder)
        PageSettings.Controls.Add(ButtonSimSwapFolder)
        PageSettings.Controls.Add(LabelSimSwap)
        PageSettings.Controls.Add(TextSimSwapFolder)
        PageSettings.Controls.Add(ButtonAnaconda)
        PageSettings.Controls.Add(LabelAnaconda)
        PageSettings.Controls.Add(TextAnaconda)
        PageSettings.Location = New Point(8, 65)
        PageSettings.Margin = New Padding(4, 5, 4, 5)
        PageSettings.Name = "PageSettings"
        PageSettings.Padding = New Padding(4, 5, 4, 5)
        PageSettings.Size = New Size(1388, 1153)
        PageSettings.TabIndex = 2
        PageSettings.Text = "Settings"
        PageSettings.UseVisualStyleBackColor = True
        ' 
        ' ButtonRunThisCommand
        ' 
        ButtonRunThisCommand.Location = New Point(1262, 281)
        ButtonRunThisCommand.Name = "ButtonRunThisCommand"
        ButtonRunThisCommand.Size = New Size(108, 49)
        ButtonRunThisCommand.TabIndex = 14
        ButtonRunThisCommand.Text = "RUN"
        ButtonRunThisCommand.UseVisualStyleBackColor = True
        ' 
        ' TextBoxLastCommandLine
        ' 
        TextBoxLastCommandLine.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        TextBoxLastCommandLine.Font = New Font("Courier New", 13.875F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxLastCommandLine.Location = New Point(7, 349)
        TextBoxLastCommandLine.Multiline = True
        TextBoxLastCommandLine.Name = "TextBoxLastCommandLine"
        TextBoxLastCommandLine.Size = New Size(1374, 796)
        TextBoxLastCommandLine.TabIndex = 13
        ' 
        ' CheckBoxNoWindow
        ' 
        CheckBoxNoWindow.AutoSize = True
        CheckBoxNoWindow.Location = New Point(623, 214)
        CheckBoxNoWindow.Name = "CheckBoxNoWindow"
        CheckBoxNoWindow.Size = New Size(252, 55)
        CheckBoxNoWindow.TabIndex = 12
        CheckBoxNoWindow.Text = "No Window"
        CheckBoxNoWindow.UseVisualStyleBackColor = True
        ' 
        ' CheckBox512
        ' 
        CheckBox512.AutoSize = True
        CheckBox512.Location = New Point(311, 275)
        CheckBox512.Name = "CheckBox512"
        CheckBox512.Size = New Size(114, 55)
        CheckBox512.TabIndex = 11
        CheckBox512.Text = "512"
        CheckBox512.UseVisualStyleBackColor = True
        ' 
        ' CheckBoxRunMinimized
        ' 
        CheckBoxRunMinimized.AutoSize = True
        CheckBoxRunMinimized.Location = New Point(311, 214)
        CheckBoxRunMinimized.Name = "CheckBoxRunMinimized"
        CheckBoxRunMinimized.Size = New Size(306, 55)
        CheckBoxRunMinimized.TabIndex = 10
        CheckBoxRunMinimized.Text = "Run Minimized"
        CheckBoxRunMinimized.UseVisualStyleBackColor = True
        ' 
        ' ButtonOutputOpen
        ' 
        ButtonOutputOpen.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        ButtonOutputOpen.Location = New Point(1169, 137)
        ButtonOutputOpen.Margin = New Padding(4, 5, 4, 5)
        ButtonOutputOpen.Name = "ButtonOutputOpen"
        ButtonOutputOpen.Size = New Size(85, 59)
        ButtonOutputOpen.TabIndex = 9
        ButtonOutputOpen.Text = "open"
        ButtonOutputOpen.UseVisualStyleBackColor = True
        ' 
        ' ButtonOutputFolder
        ' 
        ButtonOutputFolder.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        ButtonOutputFolder.Location = New Point(1262, 138)
        ButtonOutputFolder.Margin = New Padding(4, 5, 4, 5)
        ButtonOutputFolder.Name = "ButtonOutputFolder"
        ButtonOutputFolder.Size = New Size(108, 58)
        ButtonOutputFolder.TabIndex = 8
        ButtonOutputFolder.Text = "..."
        ButtonOutputFolder.UseVisualStyleBackColor = True
        ' 
        ' LabelOutputFolder
        ' 
        LabelOutputFolder.AutoSize = True
        LabelOutputFolder.Location = New Point(4, 138)
        LabelOutputFolder.Margin = New Padding(4, 0, 4, 0)
        LabelOutputFolder.Name = "LabelOutputFolder"
        LabelOutputFolder.Size = New Size(251, 51)
        LabelOutputFolder.TabIndex = 7
        LabelOutputFolder.Text = "Output folder"
        ' 
        ' TextBoxOutputFolder
        ' 
        TextBoxOutputFolder.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextBoxOutputFolder.BackColor = SystemColors.Info
        TextBoxOutputFolder.Location = New Point(311, 138)
        TextBoxOutputFolder.Margin = New Padding(4, 5, 4, 5)
        TextBoxOutputFolder.Name = "TextBoxOutputFolder"
        TextBoxOutputFolder.Size = New Size(850, 58)
        TextBoxOutputFolder.TabIndex = 6
        ' 
        ' ButtonSimSwapFolder
        ' 
        ButtonSimSwapFolder.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        ButtonSimSwapFolder.Location = New Point(1262, 77)
        ButtonSimSwapFolder.Margin = New Padding(4, 5, 4, 5)
        ButtonSimSwapFolder.Name = "ButtonSimSwapFolder"
        ButtonSimSwapFolder.Size = New Size(108, 58)
        ButtonSimSwapFolder.TabIndex = 5
        ButtonSimSwapFolder.Text = "..."
        ButtonSimSwapFolder.UseVisualStyleBackColor = True
        ' 
        ' LabelSimSwap
        ' 
        LabelSimSwap.AutoSize = True
        LabelSimSwap.Location = New Point(4, 77)
        LabelSimSwap.Margin = New Padding(4, 0, 4, 0)
        LabelSimSwap.Name = "LabelSimSwap"
        LabelSimSwap.Size = New Size(279, 51)
        LabelSimSwap.TabIndex = 4
        LabelSimSwap.Text = "SimSwap folder"
        ' 
        ' TextSimSwapFolder
        ' 
        TextSimSwapFolder.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextSimSwapFolder.Location = New Point(311, 77)
        TextSimSwapFolder.Margin = New Padding(4, 5, 4, 5)
        TextSimSwapFolder.Name = "TextSimSwapFolder"
        TextSimSwapFolder.Size = New Size(944, 58)
        TextSimSwapFolder.TabIndex = 3
        ' 
        ' ButtonAnaconda
        ' 
        ButtonAnaconda.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        ButtonAnaconda.Location = New Point(1262, 12)
        ButtonAnaconda.Margin = New Padding(4, 5, 4, 5)
        ButtonAnaconda.Name = "ButtonAnaconda"
        ButtonAnaconda.Size = New Size(108, 59)
        ButtonAnaconda.TabIndex = 2
        ButtonAnaconda.Text = "..."
        ButtonAnaconda.UseVisualStyleBackColor = True
        ' 
        ' LabelAnaconda
        ' 
        LabelAnaconda.AutoSize = True
        LabelAnaconda.Location = New Point(4, 13)
        LabelAnaconda.Margin = New Padding(4, 0, 4, 0)
        LabelAnaconda.Name = "LabelAnaconda"
        LabelAnaconda.Size = New Size(299, 51)
        LabelAnaconda.TabIndex = 1
        LabelAnaconda.Text = "Anaconda folder"
        ' 
        ' TextAnaconda
        ' 
        TextAnaconda.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextAnaconda.Location = New Point(311, 13)
        TextAnaconda.Margin = New Padding(4, 5, 4, 5)
        TextAnaconda.Name = "TextAnaconda"
        TextAnaconda.Size = New Size(944, 58)
        TextAnaconda.TabIndex = 0
        ' 
        ' TabResult
        ' 
        TabResult.Controls.Add(Button2)
        TabResult.Controls.Add(ButtonDelResult)
        TabResult.Controls.Add(ButtonResult)
        TabResult.Controls.Add(PictureBoxResult)
        TabResult.Controls.Add(TextBoxResult)
        TabResult.Location = New Point(8, 65)
        TabResult.Name = "TabResult"
        TabResult.Padding = New Padding(3)
        TabResult.Size = New Size(1388, 1153)
        TabResult.TabIndex = 3
        TabResult.Text = "Result"
        TabResult.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Button2.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        Button2.Location = New Point(1271, 8)
        Button2.Name = "Button2"
        Button2.Size = New Size(101, 45)
        Button2.TabIndex = 13
        Button2.Text = "out"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' ButtonDelResult
        ' 
        ButtonDelResult.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        ButtonDelResult.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonDelResult.Location = New Point(1164, 8)
        ButtonDelResult.Name = "ButtonDelResult"
        ButtonDelResult.Size = New Size(101, 45)
        ButtonDelResult.TabIndex = 12
        ButtonDelResult.Text = "del"
        ButtonDelResult.UseVisualStyleBackColor = True
        ' 
        ' ButtonResult
        ' 
        ButtonResult.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        ButtonResult.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonResult.Location = New Point(1057, 8)
        ButtonResult.Name = "ButtonResult"
        ButtonResult.Size = New Size(101, 45)
        ButtonResult.TabIndex = 11
        ButtonResult.Text = "re"
        ButtonResult.UseVisualStyleBackColor = True
        ' 
        ' PictureBoxResult
        ' 
        PictureBoxResult.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        PictureBoxResult.BackColor = Color.Moccasin
        PictureBoxResult.Location = New Point(14, 59)
        PictureBoxResult.Margin = New Padding(4, 5, 4, 5)
        PictureBoxResult.Name = "PictureBoxResult"
        PictureBoxResult.Size = New Size(1358, 1086)
        PictureBoxResult.SizeMode = PictureBoxSizeMode.Zoom
        PictureBoxResult.TabIndex = 10
        PictureBoxResult.TabStop = False
        ' 
        ' TextBoxResult
        ' 
        TextBoxResult.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextBoxResult.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point)
        TextBoxResult.Location = New Point(14, 8)
        TextBoxResult.Name = "TextBoxResult"
        TextBoxResult.ReadOnly = True
        TextBoxResult.Size = New Size(1030, 44)
        TextBoxResult.TabIndex = 0
        ' 
        ' OpenFileDialog1
        ' 
        OpenFileDialog1.FileName = "OpenFileDialog1"
        ' 
        ' ButtonTempFolder
        ' 
        ButtonTempFolder.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        ButtonTempFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonTempFolder.Location = New Point(1160, 1236)
        ButtonTempFolder.Margin = New Padding(4, 5, 4, 5)
        ButtonTempFolder.Name = "ButtonTempFolder"
        ButtonTempFolder.Size = New Size(215, 57)
        ButtonTempFolder.TabIndex = 1
        ButtonTempFolder.Text = "Open Temp Folder"
        ButtonTempFolder.UseVisualStyleBackColor = True
        ' 
        ' ButtonOpenOutputFolder
        ' 
        ButtonOpenOutputFolder.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        ButtonOpenOutputFolder.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonOpenOutputFolder.Location = New Point(919, 1234)
        ButtonOpenOutputFolder.Margin = New Padding(4, 5, 4, 5)
        ButtonOpenOutputFolder.Name = "ButtonOpenOutputFolder"
        ButtonOpenOutputFolder.Size = New Size(233, 57)
        ButtonOpenOutputFolder.TabIndex = 2
        ButtonOpenOutputFolder.Text = "OUTPUT Folder"
        ButtonOpenOutputFolder.UseVisualStyleBackColor = True
        ' 
        ' LabelLast
        ' 
        LabelLast.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        LabelLast.AutoSize = True
        LabelLast.Font = New Font("Microsoft Himalaya", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        LabelLast.Location = New Point(2, 1231)
        LabelLast.Margin = New Padding(4, 0, 4, 0)
        LabelLast.Name = "LabelLast"
        LabelLast.Size = New Size(38, 21)
        LabelLast.TabIndex = 3
        LabelLast.Text = "Last:"
        ' 
        ' LabelLastFileName
        ' 
        LabelLastFileName.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        LabelLastFileName.AutoSize = True
        LabelLastFileName.Font = New Font("Microsoft Sans Serif", 7.875F, FontStyle.Regular, GraphicsUnit.Point)
        LabelLastFileName.ForeColor = Color.Green
        LabelLastFileName.Location = New Point(2, 1264)
        LabelLastFileName.Margin = New Padding(4, 0, 4, 0)
        LabelLastFileName.Name = "LabelLastFileName"
        LabelLastFileName.Size = New Size(70, 25)
        LabelLastFileName.TabIndex = 4
        LabelLastFileName.Text = "no file"
        ' 
        ' ButtonOpenLastFile
        ' 
        ButtonOpenLastFile.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        ButtonOpenLastFile.Font = New Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonOpenLastFile.Location = New Point(873, 1233)
        ButtonOpenLastFile.Margin = New Padding(4, 5, 4, 5)
        ButtonOpenLastFile.Name = "ButtonOpenLastFile"
        ButtonOpenLastFile.Size = New Size(38, 58)
        ButtonOpenLastFile.TabIndex = 5
        ButtonOpenLastFile.Text = "."
        ButtonOpenLastFile.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        Button1.Location = New Point(1382, 1236)
        Button1.Name = "Button1"
        Button1.Size = New Size(21, 46)
        Button1.TabIndex = 6
        Button1.Text = "~"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' F
        ' 
        AutoScaleMode = AutoScaleMode.Inherit
        AutoScroll = True
        AutoSize = True
        ClientSize = New Size(1410, 1305)
        Controls.Add(Button1)
        Controls.Add(ButtonOpenLastFile)
        Controls.Add(LabelLastFileName)
        Controls.Add(LabelLast)
        Controls.Add(ButtonOpenOutputFolder)
        Controls.Add(ButtonTempFolder)
        Controls.Add(TabsBlock)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Margin = New Padding(4, 5, 4, 5)
        MinimumSize = New Size(1396, 763)
        Name = "F"
        ShowIcon = False
        SizeGripStyle = SizeGripStyle.Show
        StartPosition = FormStartPosition.Manual
        Text = "ReFace"
        TabsBlock.ResumeLayout(False)
        PageTask.ResumeLayout(False)
        PageTask.PerformLayout()
        CType(PictureBoxFace, ComponentModel.ISupportInitialize).EndInit()
        TabControlSource.ResumeLayout(False)
        TabPageSourceImage.ResumeLayout(False)
        TabPageSourceImage.PerformLayout()
        CType(PictureBoxSourceImage, ComponentModel.ISupportInitialize).EndInit()
        TabPageSourceVideo.ResumeLayout(False)
        TabPageSourceVideo.PerformLayout()
        CType(PictureBoxVideo, ComponentModel.ISupportInitialize).EndInit()
        PageTasks.ResumeLayout(False)
        PageSettings.ResumeLayout(False)
        PageSettings.PerformLayout()
        TabResult.ResumeLayout(False)
        TabResult.PerformLayout()
        CType(PictureBoxResult, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TabsBlock As TabControl
    Friend WithEvents PageTask As TabPage
    Friend WithEvents PageTasks As TabPage
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents ButFaceFolder As Button
    Friend WithEvents CheckBoxFacesFromFolder As CheckBox
    Friend WithEvents ButtonFaceFile As Button
    Friend WithEvents LabelFace As Label
    Friend WithEvents TextFace As TextBox
    Friend WithEvents PictureBoxFace As PictureBox
    Friend WithEvents PageSettings As TabPage
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents ButtonSimSwapFolder As Button
    Friend WithEvents LabelSimSwap As Label
    Public WithEvents TextSimSwapFolder As TextBox
    Friend WithEvents ButtonAnaconda As Button
    Friend WithEvents LabelAnaconda As Label
    Friend WithEvents TextAnaconda As TextBox
    Friend WithEvents TextBoxSourceImage As TextBox
    Friend WithEvents LabelSource As Label
    Friend WithEvents LabelSourceVideo As Label
    Friend WithEvents TextBoxSourceVideo As TextBox
    Friend WithEvents TabControlSource As TabControl
    Friend WithEvents TabPageSourceImage As TabPage
    Friend WithEvents ButtonSourceImageFile As Button
    Friend WithEvents PictureBoxSourceImage As PictureBox
    Friend WithEvents TabPageSourceVideo As TabPage
    Friend WithEvents CheckBoxSourceImagesFromFolder As CheckBox
    Friend WithEvents ButtonSourceImageFolder As Button
    Friend WithEvents ButtonOutputFolder As Button
    Friend WithEvents LabelOutputFolder As Label
    Public WithEvents TextBoxOutputFolder As TextBox
    Friend WithEvents ButtonTempFolder As Button
    Friend WithEvents ButtonOpenOutputFolder As Button
    Friend WithEvents LabelLast As Label
    Friend WithEvents LabelLastFileName As Label
    Friend WithEvents ButtonImageAddTask As Button
    Friend WithEvents ButtonImageStart As Button
    Friend WithEvents ButtonSourceVideoPlay As Button
    Friend WithEvents ButtonSourceVideoFolder As Button
    Friend WithEvents CheckBoxSourceVideoFromFolder As CheckBox
    Friend WithEvents ButtonSourceVideoFile As Button
    Friend WithEvents ButtonVideoAddTask As Button
    Friend WithEvents ButtonVideoStart As Button
    Friend WithEvents ButtonOpenLastFile As Button
    Friend WithEvents PictureBoxFaceLabel As Label
    Friend WithEvents LabelPrefix As Label
    Friend WithEvents LabelSourceName As Label
    Friend WithEvents PictureBoxSourceLabel As Label
    Friend WithEvents LabelSourceVideoName As Label
    Friend WithEvents PictureBoxSourceVideoLabel As Label
    Friend WithEvents CheckBoxFaceHidden As CheckBox
    Friend WithEvents CheckBoxSourceHidden As CheckBox
    Friend WithEvents CaptionName As Label
    Friend WithEvents TextBoxName As TextBox
    Friend WithEvents LabelNameSource As Label
    Friend WithEvents TextBoxSourceName As TextBox
    Friend WithEvents TabResult As TabPage
    Friend WithEvents TextBoxResult As TextBox
    Friend WithEvents ButtonResult As Button
    Friend WithEvents PictureBoxResult As PictureBox
    Friend WithEvents ReFace As Button
    Friend WithEvents ReSource As Button
    Friend WithEvents ButtonDelResult As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents ButtonOutputOpen As Button
    Friend WithEvents ButtonTasksRemove As Button
    Friend WithEvents ButtonTasksClear As Button
    Friend WithEvents ButtonTasksRun As Button
    Friend WithEvents ButtonTasksOneByOne As Button
    Friend WithEvents ButtonTasksOneBatch As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents CheckBoxRunMinimized As CheckBox
    Friend WithEvents ButtonNext As Button
    Friend WithEvents ButtonLoadNext As Button
    Friend WithEvents ButtonLoadPrev As Button
    Friend WithEvents ButtonRotate As Button
    Friend WithEvents CheckBox512 As CheckBox
    Friend WithEvents CheckBoxNoWindow As CheckBox
    Friend WithEvents PictureBoxVideo As PictureBox
    Friend WithEvents TextBoxNameSourceVideo As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ButtonDeleteSourceImage As Button
    Friend WithEvents TextBoxLastCommandLine As TextBox
    Friend WithEvents ButtonRunThisCommand As Button
End Class
