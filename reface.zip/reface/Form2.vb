﻿Public Class Form2

    Dim LabelTimerc As Integer
    Public filetoload As String = ""

    Private Sub ButtonDelResult_Click(sender As Object, e As EventArgs) Handles ButtonDelResult.Click
        If TextBoxResult.Text <> "" Then
            Try
                PictureBoxResult.Image.Dispose()
                My.Computer.FileSystem.DeleteFile(TextBoxResult.Text)
                TextBoxResult.Text = ""
                LabelTimer.Text = "D"
            Catch
                LabelTimer.Text = "E"
            End Try
        End If
    End Sub

    Private Sub ButtonResult_Click(sender As Object, e As EventArgs) Handles ButtonResult.Click
        refreshResultImage()
    End Sub


    Private Sub refreshResultImage()

        Try
            Dim tryFile As New IO.FileInfo(filetoload)
            If tryFile.Exists Then
                Timer1.Enabled = False
                LabelTimer.Text = "."
                Dim tryFileName = tryFile.Name
                Dim ImageSource = New Bitmap(filetoload, True)
                PictureBoxResult.Image = ImageSource
                Me.Refresh()
                TextBoxResult.Text = filetoload

                ' Form1.PictureBoxResult.Image = ImageSource

                '          PictureBoxResult.Image.Dispose()
                ' LabelSourceName.Text = Microsoft.VisualBasic.Left(tryFileName, 12)
                ' PictureBoxSourceLabel.Text = ImageSource.Size.ToString + " - " + tryFile.Length.ToString
            Else
                ' LabelTimer.Text = "E"
            End If
        Catch ex As Exception
            LabelTimer.Text = "E"
        End Try

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        LabelTimerc = LabelTimerc + 1
        If LabelTimerc = 1 Then
            LabelTimer.Text = "-"
        ElseIf LabelTimerc = 2 Then
            LabelTimer.Text = "/"
        ElseIf LabelTimerc = 3 Then
            LabelTimer.Text = "↓"
        ElseIf LabelTimerc = 4 Then
            LabelTimer.Text = "∟"
        ElseIf LabelTimerc = 5 Then
            LabelTimer.Text = "→"
            LabelTimerc = 0
        End If

        refreshResultImage()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles LabelTimer.Click

    End Sub
End Class
